// Cloudflare Workerをデプロイした後、URLを設定してください。
window.ADMIN_API_URL = "https://YOUR-WORKER.YOUR-SUBDOMAIN.workers.dev";
